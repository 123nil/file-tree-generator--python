-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 14, 2021 at 02:34 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `knowme`
--
CREATE DATABASE IF NOT EXISTS `knowme` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `knowme`;

-- --------------------------------------------------------

--
-- Table structure for table `chatbot_hints`
--

CREATE TABLE `chatbot_hints` (
  `id` int(11) NOT NULL,
  `question` varchar(100) NOT NULL,
  `reply` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chatbot_hints`
--

INSERT INTO `chatbot_hints` (`id`, `question`, `reply`) VALUES
(1, 'HI||Hello||Hola', 'Hello, how are you.'),
(2, 'How are you', 'Good to see you again!'),
(3, 'what is your name||whats your name', 'My name is smart Bot'),
(4, 'what should I call you', 'You can call me PHP Bot'),
(5, 'Where are you from', 'I m from (Bihar)India'),
(6, 'Bye||See you later||Have a Good Day', 'Sad to see you are going. Have a nice day'),
(7, 'from where can I get you', 'you can mail me at afaquezainsiwan@gmail.com ');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `id` int(11) NOT NULL,
  `message` text NOT NULL,
  `added_on` datetime NOT NULL,
  `type` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`id`, `message`, `added_on`, `type`) VALUES
(1, 'Hi', '2020-04-22 12:41:04', 'user'),
(2, 'Hello, how are you.', '2020-04-22 12:41:05', 'bot'),
(11, 'from where can i get you', '2021-12-13 07:11:40', 'user'),
(12, 'you can mail me at afaquezainsiwan@gmail.com or can connect on linkedin by following the link linked', '2021-12-13 07:11:40', 'bot'),
(13, 'from where can i get you', '2021-12-13 07:13:15', 'user'),
(14, 'you can mail me at afaquezainsiwan@gmail.com ', '2021-12-13 07:13:16', 'bot'),
(15, 'hola', '2021-12-13 07:13:26', 'user'),
(18, 'Sorry not be able to understand you', '2021-12-13 07:13:55', 'bot'),
(21, 'hola', '2021-12-13 10:24:49', 'user'),
(22, 'Hello, how are you.', '2021-12-13 10:24:49', 'bot'),
(23, 'fgghgjuyuy', '2021-12-13 10:57:37', 'user'),
(24, 'Sorry not be able to understand you', '2021-12-13 10:57:37', 'bot'),
(25, 'hola', '2021-12-13 10:58:35', 'user'),
(26, 'Hello, how are you.', '2021-12-13 10:58:35', 'bot'),
(27, 'from where can i get you', '2021-12-13 10:59:08', 'user'),
(28, 'you can mail me at afaquezainsiwan@gmail.com ', '2021-12-13 10:59:08', 'bot'),
(29, 'where are you from', '2021-12-13 11:00:17', 'user'),
(30, 'I m from (Bihar)India', '2021-12-13 11:00:17', 'bot'),
(31, 'hii', '2021-12-13 11:00:48', 'user'),
(32, 'Sorry not be able to understand you', '2021-12-13 11:00:48', 'bot'),
(33, 'hi', '2021-12-13 11:00:52', 'user'),
(34, 'Hello, how are you.', '2021-12-13 11:00:52', 'bot');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chatbot_hints`
--
ALTER TABLE `chatbot_hints`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chatbot_hints`
--
ALTER TABLE `chatbot_hints`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
